const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const connectDB = require('./config/db');
dotenv.config();
connectDB();
const app = express();
app.use(cors());
app.use(express.json());
// serve static 'public' if exists
const path = require('path');
app.use(express.static(path.join(__dirname, 'public')));
// routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/drivers', require('./routes/drivers'));
app.use('/api/bookings', require('./routes/bookings'));
app.use('/api/feedbacks', require('./routes/feedbacks'));
app.get('/', (req,res)=> res.send('EaseDrive API running'));
const PORT = process.env.PORT || 5000;
app.listen(PORT, ()=> console.log('Server started on port', PORT));
